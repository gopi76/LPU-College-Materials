import javax.swing.*;

import java.awt.Color;

import java.awt.event.*;

public class ColorCombo {
    public static void main(String[] args) {
        JFrame f = new JFrame("Color");
        String Colors[] = { "Red", "Blue", "Yellow", "Black" };
        JComboBox bx = new JComboBox<String>(Colors);
        bx.setBounds(30, 50, 100, 30);
        JButton b = new JButton("Change Color");
        b.setBounds(100, 100, 100, 30);
        b.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                switch (bx.getSelectedIndex()) {
                    case 0:
                        f.getContentPane().setBackground(Color.red);

                        break;
                    case 1:
                        f.getContentPane().setBackground(Color.blue);
                        break;
                    case 2:
                        f.getContentPane().setBackground(Color.yellow);
                        break;
                    case 3:
                        f.getContentPane().setBackground(Color.black);
                        break;

                    default:
                        break;
                }
            }
        });

        f.add(bx);
        f.add(b);
        f.setSize(500, 500);
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        f.setLayout(null);
        f.setResizable(true);
        f.setLocationRelativeTo(null);

        f.setVisible(true);

    }
}
