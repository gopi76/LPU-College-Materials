import java.nio.file.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;

public class ReadingFiles {
    public static void main(String args[]) {
        try {
            Path p1 = Paths.get("C:/Users/chund/Desktop/androidca.txt");
            List<String> data = Files.readAllLines(p1);
            for (String str : data) {
                System.out.println(str);

            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}
