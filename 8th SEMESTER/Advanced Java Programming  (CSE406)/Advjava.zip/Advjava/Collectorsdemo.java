import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.*;
class streamcollectordemo{
public static void main(String[] args)
{
List<String> ls = Arrays.asList("Pink","Yellow","Purple","Magenta","Green");
List<String> str = ls.stream()
.filter(str2 -> str2.length()>4 && str2.length()<=6)
.collect(Collectors.toList());
str.forEach(System.out::println);
}
}