class alpha implements Runnable {
    public void run() {
        for (int i = 65; i <= 92; i++) {
            System.out.println((char) i);
            try {
                Thread.sleep(800);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        System.out.println("Alphabet class Ended!!");
    }

}

class number implements Runnable {
    public void run() {
        for (int i = 1; i <= 20; i++) {
            System.out.println(i);
            try {
                Thread.sleep(800);
            } catch (Exception e) {
                e.getMessage();
            }
        }
        System.out.println("Number Class Ended !!!");
    }

}

class alphaNumerics {
    public static void main(String[] args) {
        alpha a = new alpha();
        number a1 = new number();
        Thread t1 = new Thread(a);
        t1.start();
        Thread t2 = new Thread(a1);
        t2.start();
    }
}
