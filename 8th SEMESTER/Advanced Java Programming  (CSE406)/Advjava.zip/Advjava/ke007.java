import java.sql.*;

class ke007 {
    public static void main(String args[]) {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/ke007", "root", "123");
            Statement stmt = con.createStatement();
            // String ins="insert into student values(1,'shruti')";
            // stmt.executeUpdate("Update student set name='mohan' where stuid=1");
            stmt.executeUpdate("delete from emp where empid=101");
            System.out.println("Recorde deleted");
            stmt.close();
            con.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}