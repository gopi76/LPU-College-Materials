import java.util.Scanner;

public class ElectronicWatch {
    public static void main(String[] args) {
        // Read input value (seconds since midnight) from System.in
        Scanner scanner = new Scanner(System.in);
        int secondsSinceMidnight = scanner.nextInt();
        scanner.close();

        // Calculate hours, minutes, and seconds
        int hours = secondsSinceMidnight / 3600;
        int minutes = (secondsSinceMidnight % 3600) / 60;
        int seconds = secondsSinceMidnight % 60;

        // Format the output and print to System.out
        System.out.printf("%d:%02d:%02d%n", hours, minutes, seconds);
    }
}
