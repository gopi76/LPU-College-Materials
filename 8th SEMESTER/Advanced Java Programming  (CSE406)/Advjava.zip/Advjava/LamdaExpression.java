@FunctionalInterface
interface Hotel
{
public void order();
}
class LamdaExpression
{
public static void main(String[] args)
{
String item  = "Sandwich";
Hotel H1 = ()-> {
System.out.println("My Ordered Item is :- "+item);
};
H1.order();
}
}