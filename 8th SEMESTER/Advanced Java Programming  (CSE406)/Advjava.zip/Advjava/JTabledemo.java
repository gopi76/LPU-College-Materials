import javax.swing.*;
import java.awt.Color;

public class JTabledemo {

    public static void main(String[] args) {
        JFrame f = new JFrame("Table");
        f.setSize(520, 500);
        String data[][] = { { "101", "venkat", "12323" }, { "121", "tharun", "1574" }, { "784", "sai", "785" },
                { "567", "ashu", "12323" }, { "125", "venky", "125788" }, { "125", "venky", "125788" },
                { "125", "venky", "125788" } };
        String coloumn[] = { "empid", "empname", "emsal" };
        JTable tb = new JTable(data, coloumn);

        JScrollPane sp = new JScrollPane(tb);
        sp.setBounds(30, 40, 60, 50);
        f.add(sp);

        f.setResizable(false);
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        f.setLocationRelativeTo(null);
        f.getContentPane().setBackground(Color.black);
        f.setVisible(true);

    }

}
