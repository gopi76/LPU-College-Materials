import javax.swing.*;
import java.awt.Graphics;
import java.awt.Color;
import java.awt.Font;
import java.awt.*;

class blink extends Canvas {
    public void paint(Graphics g) {
        setForeground(Color.white);
        setBackground(Color.black);
        g.fillOval(90, 200, 150, 100);
        repaint(100000);
    }

    public static void main(String args[]) {
        blink d = new blink();
        JFrame f = new JFrame("KeyEvent application");
        f.add(d);
        f.setSize(400, 400);
        f.setResizable(false);
        f.setLocationRelativeTo(null);
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        // f.setLayout(null);
        f.setVisible(true);
    }
}