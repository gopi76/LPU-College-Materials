import java.util.stream.*;
import java.util.List;
import java.util.Arrays;
class Cubesofintegers
{
public static void main(String args[])
{
List<Integer> ls=Arrays.asList(7,8,1,3,9,10,67,29);
ls.stream()
.map(x->x*x*x).sorted()
.forEach(System.out::println);
}
}