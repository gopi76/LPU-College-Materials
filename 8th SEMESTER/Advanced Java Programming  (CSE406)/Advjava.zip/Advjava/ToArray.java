import java.util.*;
import java.util.stream.*;
import java.util.Arrays;
import java.util.List;

class ToArray{
public static void main(String argds[]){

List<String> al = Arrays.asList("1","venky","4567","%$8","H4fy","hello123");
Object ar[] = al.stream().toArray();
System.out.println(ar.length);
for(Object i : ar){
System.out.println(i);
}
}
}