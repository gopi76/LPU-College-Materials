import java.util.*;
import java.util.stream.*;
import java.util.stream.Collectors;

class student{

String name;
double cgpa;int id;

student(String name, double cgpa,int id){
this.id=id;
this.name=name;
this.cgpa = cgpa;

}
}

class CgpaFilter{
public static void main(String... arhs){

List<student> ar = new ArrayList<>();
ar.add(new student("venky",8.03,120));
ar.add(new student("ram",7.3,140));

ar.add(new student("sai",6.03,148));
ar.add(new student("guna",9.4,785));
ar.add(new student("tharun",5.6,963));
Set<Double> studentcgpa = ar.stream().filter(x->x.cgpa>6).map(x->x.cgpa).collect(Collectors.toSet());
System.out.println(studentcgpa);
}
}

