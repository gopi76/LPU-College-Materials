import javax.swing.*;
import java.awt.event.*;
class frames
{
JFrame f;
frames()
{
f=new JFrame("JComboBox");
String color[]={"Red","Blue","Pink","Purple","Magenta","Cyan"};
JComboBox cb=new JComboBox<String>(color);
cb.setBounds(30,40,100,30);
f.add(cb);
f.setSize(400,400);
f.setLocationRelativeTo(null);
f.setResizable(false);
f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
f.setLayout(null);
f.setVisible(true);
}
public static void main(String... shruti)
{
new frames();
}
}