import javax.swing.*;
import java.awt.event.*;
class frames1
{
public static void main(String... shruti)
{
JFrame f=new JFrame("JRadioButton");
JRadioButton rb1=new JRadioButton("Married");
rb1.setBounds(30,40,100,30);
JRadioButton rb2=new JRadioButton("Un-Married");
rb2.setBounds(30,80,100,30);
ButtonGroup bg=new ButtonGroup();
bg.add(rb1);
bg.add(rb2);
JLabel lb=new JLabel();
lb.setBounds(30,150,200,30);
JButton b=new JButton("Marital Status");
b.setBounds(30,200,100,30);
b.addActionListener(new ActionListener(){
public void actionPerformed(ActionEvent e)
{
if(rb1.isSelected())
{
lb.setText("Marrital status of employee is married");
}
if(rb2.isSelected())
{
lb.setText("Marrital status of employee is un-married");
}}});
f.add(lb);
f.add(b);
f.add(rb1);
f.add(rb2);
f.setSize(400,400);
f.setLocationRelativeTo(null);
f.setResizable(false);
f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
f.setLayout(null);
f.setVisible(true);
}
}