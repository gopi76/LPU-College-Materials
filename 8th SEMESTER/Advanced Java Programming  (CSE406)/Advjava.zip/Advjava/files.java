import java.nio.file.*;
import java.util.stream.*;
import java.io.*;

class files {
    public static void main(String ars[]) throws IOException {
        Path p = Paths.get("C:/Users/chund/Desktop/3.2");
        System.out.println(p.getRoot());
        try {
            Stream<Path> str = Files.list(p);
            str.forEach(x -> {
                String name = x.getFileName().toString();
                String token[] = name.split("\\.");
                String extension = token[token.length - 1];
                try {
                    Path d = Paths.get(extension);
                    Files.createDirectory(d);

                } catch (Exception e) {
                    System.out.println(e);
                }
            });

        } catch (Exception e) {
            e.printStackTrace();
        }

    }
}
