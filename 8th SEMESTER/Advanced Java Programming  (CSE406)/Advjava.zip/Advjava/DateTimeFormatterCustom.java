import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class DateTimeFormatterCustom {

    public static void main(String[] args) {
        LocalDateTime now = LocalDateTime.now();
        System.out.println("Before Fromating:- " + now);
        System.out.println(now.plusDays(10));
        System.out.println(now.minusDays(20));
        DateTimeFormatter format = DateTimeFormatter.ofPattern("dd-MM-yyyy mm:hh:ss");
        String formatDateTime = now.format(format);
        System.out.println("After Foranting :- " + formatDateTime);
    }
}
