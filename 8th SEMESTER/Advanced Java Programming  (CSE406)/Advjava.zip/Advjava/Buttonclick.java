import java.awt.event.*;
import java.awt.Color;
import javax.swing.*;

public class Buttonclick{
public static void main(String[] arhd){

JFrame f = new JFrame("Text Field Application");
JButton b = new JButton("Push Button");
b.setBounds(15,20,120,150);
b.setForeground(Color.red);

JTextField tf = new JTextField();
tf.setBounds(120,120,100,150);
tf.setBackground(Color.black);
tf.setForeground(Color.cyan);
b.addActionListener(new ActionListener(){
public void actionPerformed(ActionEvent e){
tf.setText("Hello VEnky");
}
}
);




f.add(b);
f.add(tf);
f.setSize(500,500);
f.setResizable(false);
f.setLocationRelativeTo(null);
f.getContentPane().setBackground(Color.yellow);
f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
f.setLayout(null);
f.setVisible(true);
}
}