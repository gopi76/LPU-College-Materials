import java.util.*;
import java.util.stream.*;

class Student {
    String name;
    double cgpa;
    int id;

    Student(String name, double cgpa, int id) {
        this.name = name;
        this.cgpa = cgpa;
        this.id = id;

    }

    public String toString() {
        return "Max Cgpa is :- " + cgpa + ".";
    }
}

class StudentMaxCgpa {
    public static void main(String[] args) {
        ArrayList<Student> arr = new ArrayList<>();
        arr.add(new Student("venky", 8.03, 120));
        arr.add(new Student("ram", 7.3, 140));

        arr.add(new Student("sai", 6.03, 148));
        arr.add(new Student("guna", 9.4, 785));
        arr.add(new Student("tharun", 5.6, 963));
        Stream<Student> str = arr.stream();
        Student maxCgpa = str.max((a, b) -> a.cgpa > b.cgpa ? 1 : -1).get();
        // double c = str.filter(str2 -> str2.max(cgpa));; //error in this line
        System.out.println(maxCgpa.name + "  with cgpa " + maxCgpa.cgpa);

    }
}