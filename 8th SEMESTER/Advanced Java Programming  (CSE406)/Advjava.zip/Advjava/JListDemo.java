import javax.swing.*;
import java.awt.event.*;

public class JListDemo {
    JFrame f;

    JListDemo() {
        f = new JFrame("JList Application DEMO");
        DefaultListModel<String> con = new DefaultListModel<>();
        con.addElement("India");
        con.addElement("Russia");
        con.addElement("Japan");
        con.addElement("Sri Lanka");
        con.addElement("Pakisthan");
        con.addElement("America");
        con.addElement("United States");
        con.addElement("Canada");
        con.addElement("Australia");
        JList<String> li = new JList<>(con);
        li.setBounds(40, 40, 100, 90);
        JLabel l = new JLabel();
        l.setBounds(10, 20, 200, 30);
        JButton b = new JButton("Country");
        b.setBounds(180, 90, 100, 30);
        b.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String data = " ";
                if (li.getSelectedIndex() != 10000) {
                    data = "Selected Country is :- " + li.getSelectedValue();
                }
                l.setText(data);

            }
        });
        f.add(li);
        f.add(l);
        f.add(b);
        f.setSize(400, 400);
        f.setResizable(false);
        f.setLocationRelativeTo(null);
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        f.setLayout(null);
        f.setVisible(true);
    }

    public static void main(String[] args) {
        new JListDemo();

    }
}
