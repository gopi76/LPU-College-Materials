
import javax.swing.*;
import java.awt.event.*;
import java.awt.Color;

public class Temperature {
    public static void main(String[] args) {
        JFrame f = new JFrame("Temperature");
        JLabel l1 = new JLabel("Degrees");
        l1.setBounds(30, 30, 100, 20);
        JTextField tf1 = new JTextField();
        tf1.setBounds(150, 30, 50, 20);
        JLabel l2 = new JLabel("Convert Temperature from Degrees to Fahrenheit");
        l2.setBounds(50, 10, 300, 20);
        JLabel l3 = new JLabel();
        l3.setBounds(50, 200, 50, 30);
        JButton b = new JButton("CONVERT");
        b.setBounds(50, 100, 150, 30);
        b.setBackground(Color.green);
        b.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                double d = Double.parseDouble(tf1.getText());
                double fa = d * (9 / 5) + 32;
                l3.setText(Double.toString(fa));
            }
        });
        f.add(l1);
        f.add(l2);
        f.add(l3);
        f.add(tf1);
        f.add(b);
        f.setSize(500, 500);
        f.setLayout(null);
        f.setLocationRelativeTo(null);
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        f.setResizable(true);
        f.getContentPane().setBackground(Color.cyan);
        f.setVisible(true);
    }
}
