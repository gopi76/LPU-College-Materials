import java.util.*;
import java.util.stream.*;

class stream{
public static void main(String [] args)
{
ArrayList<Integer> ar = new ArrayList<>();
ar.add(3);
ar.add(4);
ar.add(6);
ar.add(8);
ar.add(10);
ar.add(3);
ar.add(2);
ar.add(5);
ar.add(1);
ar.add(2);
ar.add(10);
ar.add(5);
System.out.println(ar);
Stream<Integer> str = ar.stream();
str = str.distinct().sorted();
str.forEach(x->System.out.println(x));




}
}