import java.util.stream.*;
import java.util.List;
import java.util.Arrays;

class LengthofString {
    public static void main(String args[]) {
        List<String> ls = Arrays.asList

        ("india", "CANADA", "amErica", "Australia", "india");
        ls.stream()
                .map(String::toLowerCase).sorted().distinct()
                .map(str -> str.length())
                .forEach(System.out::println);
    }
}