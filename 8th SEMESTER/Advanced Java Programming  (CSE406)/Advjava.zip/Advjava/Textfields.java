import java.util.*;
import java.awt.Color;
import javax.swing.*;

public class Textfields{
public static void main(String[] arhd){

JFrame f = new JFrame("Text Field Application");
JPanel p = new JPanel(); //default consutructor no args should be there
p.setBounds(15,15,120,150);
p.setBackground(Color.red);
JTextField tf = new JTextField("Hello Lpu");
tf.setBounds(20,20,100,150);
tf.setBackground(Color.black);
tf.setForeground(Color.white);
p.add(tf);


JPanel p1 = new JPanel(); //default consutructor no args should be there
p1.setBounds(120,150,250,300);
p1.setBackground(Color.green);
JTextField tf1 = new JTextField("Venkat Here");
tf1.setBounds(50,20,100,150);
tf1.setBackground(Color.black);
tf1.setForeground(Color.white);
p1.add(tf1);

f.add(p);
f.add(p1);
f.setSize(500,500);
f.setResizable(false);
f.setLocationRelativeTo(null);
f.getContentPane().setBackground(Color.yellow);
f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
f.setLayout(null);
f.setVisible(true);
}
}