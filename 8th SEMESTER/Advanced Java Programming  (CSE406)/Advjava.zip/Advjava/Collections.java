import java.util.*;

class employee{
String name;
int empid;

employee(String name, int empid){
this.name = name;
this.empid = empid;
}
public String toString()
{
return "Employee name is :- "+name+" and employee id is :- "+empid+".";
}
}
class Collections
{
public static void main(String [] Args)
{
ArrayList<employee> arr = new ArrayList<>();
arr.add(new employee("venkat",120));
arr.add(new employee("sai",161));
arr.add(new employee("RAM",2201));
arr.add(new employee("abhi",748));
Iterator<employee> itr = arr.iterator();
while(itr.hasNext())
{
System.out.println(itr.next());
}
//arr.forEach(s->System.out.println(s));
}
}