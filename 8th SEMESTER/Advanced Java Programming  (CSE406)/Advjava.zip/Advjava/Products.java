import java.util.*;
import java.util.stream.*;

class homeproduct{
String name;
int quantity;
float cost;

homeproduct(String name, int quantity,float cost){
this.name = name;
this.quantity = quantity;
this.cost = cost;
}
}
class Products{
public static void main(String args[]){
ArrayList<homeproduct> ar = new ArrayList<>();
ar.add(new homeproduct("Ac",1,25000));
ar.add(new homeproduct("Fridge",1,38000));
ar.add(new homeproduct("HomeTheatre",1,80000));
ar.add(new homeproduct("Heater",1,85000));
ar.add(new homeproduct("one plus",1,70000));
Stream<homeproduct> str = ar.stream();
float budget = str.map(product->product.cost)
//.reduce(0.0f,(sum,cost)-> sum+cost);
.reduce(0.0f,Float::sum);
System.out.println("Total cost is :- "+ budget);


}
}