import java.util.Locale;

public class Localization {
    public static void main(String[] args) {
        Locale l1 = Locale.getDefault();
        Locale l = new Locale("fr", "FR", "fr");
        Locale en = new Locale("en", "US");
        Locale no = new Locale("no", "NO");
        Locale es = new Locale("es", "ES");
        Locale sv = new Locale("sv", "SE");
        System.out.println("English language in USA " + en.getDisplayLanguage());
        System.out.println("English language in Norway " + en.getDisplayLanguage(no));
        System.out.println("English language in Spain " + en.getDisplayLanguage(es));
        System.out.println("English language in Sweden " + en.getDisplayLanguage(sv));

        System.out.println(l.getDisplayCountry()); // Displays coutry name
        System.out.println(l.getDisplayLanguage()); // displays language name
        System.out.println(l.getDisplayName()); // displays language and country name
        System.out.println(l.getISO3Country()); // displays first 3 letters of country
        System.out.println(l.getISO3Language()); // displays first 3 letters of language
        System.out.println(l.getLanguage()); // displays code of language
        System.out.println(l.getCountry()); // displays code of country
        System.out.println(l.getVariant()); // display the code of lnaguage if only passed in the arguments above

    }

}
