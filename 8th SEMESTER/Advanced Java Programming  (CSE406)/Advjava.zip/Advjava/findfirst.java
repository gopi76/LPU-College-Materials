import java.util.*;
import java.util.stream.*;
import java.util.List;
import java.util.Arrays;

class findfirst {
    public static void main(String... venk) {
        Integer[] ar = { 178, 2, 4, 8, 6, 78, 4, 9, 28 };
        Stream<Integer> str = Arrays.stream(ar);
        Optional<Integer> op = str.findFirst();
        op.ifPresent(System.out::println);
    }
}