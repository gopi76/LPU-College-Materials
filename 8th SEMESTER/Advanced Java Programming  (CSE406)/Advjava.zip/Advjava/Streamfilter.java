import java.util.Arrays;
import java.util.List;
import java.util.stream.*;
class Streamfilter{
public static void main(String[] args)
{
List<String> ls = Arrays.asList("Pink","Yellow","Purple","Magenta","Green");
Stream<String> str = ls.stream();
Stream<String> str1 = str.filter(str2 -> str2.length()>=6);
str1.forEach(x->System.out.println(x));
}
}