import java.util.*;
import java.util.stream.*;

class Employee {
    String empname;
    int empid;
    int sal;
    char gen;

    Employee(String empname, int empid, int sal, char gen) {
        this.empname = empname;
        this.empid = empid;
        this.sal = sal;
        this.gen = gen;

    }

    public static void print(Employee e) {
        System.out.println(e.empname + " " + e.empid + " " + e.sal + " " + e.gen);
    }

    public String toString() {
        return "Employee name is :- " + empname + " and employee id is :- " + empid + "" + sal + " " + gen + ".";
    }

    public static void main(String[] args) {
        ArrayList<Employee> arr = new ArrayList<>();
        arr.add(new Employee("venkat", 120, 15000, 'M'));
        arr.add(new Employee("ashi", 161, 18000, 'F'));
        arr.add(new Employee("RAM", 2201, 18000, 'M'));
        arr.add(new Employee("abhi", 748, 30000, 'M'));
        arr.add(new Employee("vinay", 145, 28000, 'M'));

        Iterator<Employee> itr = arr.iterator();
        while (itr.hasNext()) {
            System.out.println(itr.next());
        }

        Stream<Employee> st = arr.stream().filter(x -> x.sal > 15000 && x.sal < 30000 && x.gen == 'M');
        st.forEach(x -> print(x));

    }
}