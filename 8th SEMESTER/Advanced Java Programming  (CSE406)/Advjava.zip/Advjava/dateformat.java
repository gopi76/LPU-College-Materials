
import java.text.DateFormat;
import java.util.Date;
import java.util.Locale;

public class dateformat {
    static void printTime(Locale locale) {
        DateFormat formatter = DateFormat.getTimeInstance(DateFormat.DEFAULT, locale); // we can print date instance by
                                                                                       // changing .getDateinstance
        Date currentdate = new Date();
        String time = formatter.format(currentdate);
        System.out.println(time + " in Particular locale " + locale);
    }

    public static void main(String[] args) {
        printTime(Locale.UK);
        printTime(Locale.US);
        printTime(Locale.FRANCE);
        printTime(Locale.GERMANY);
        printTime(Locale.CHINA);

    }
}
