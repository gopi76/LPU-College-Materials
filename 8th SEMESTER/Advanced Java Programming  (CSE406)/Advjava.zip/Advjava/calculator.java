import javax.swing.*;
import java.awt.Color;
import java.awt.event.*;

public class calculator {
    public static void main(String... args) {
        JFrame f = new JFrame("Calculator");
        JLabel l1 = new JLabel("First Number");
        l1.setBounds(20, 30, 100, 30);
        JLabel l2 = new JLabel("Second Number");
        l2.setBounds(20, 70, 100, 30);
        JLabel l3 = new JLabel("Result");
        l3.setBounds(20, 200, 100, 30);
        JTextField t1 = new JTextField();
        t1.setBounds(140, 30, 100, 30);
        JTextField t2 = new JTextField();
        t2.setBounds(140, 70, 100, 30);
        JTextField t3 = new JTextField();
        t3.setBounds(80, 200, 100, 30);
        t3.setEditable(false);

        JButton b1 = new JButton("+");
        b1.setBounds(20, 150, 50, 30);

        b1.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                int res = Integer.parseInt(t1.getText()) + Integer.parseInt(t2.getText());

                t3.setText(String.valueOf(res));

            }
        });
        JButton b2 = new JButton("*");
        b2.setBounds(80, 150, 50, 30);

        b2.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                int res = Integer.parseInt(t1.getText()) * Integer.parseInt(t2.getText());

                t3.setText(String.valueOf(res));

            }
        });
        JButton b3 = new JButton("%");
        b3.setBounds(140, 150, 50, 30);

        b3.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                int res = Integer.parseInt(t1.getText()) % Integer.parseInt(t2.getText());

                t3.setText(String.valueOf(res));

            }
        });
        JButton b4 = new JButton("/");
        b4.setBounds(200, 150, 50, 30);

        b4.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                int res = Integer.parseInt(t1.getText()) / Integer.parseInt(t2.getText());

                t3.setText(String.valueOf(res));

            }
        });
        JButton b5 = new JButton("-");
        b5.setBounds(260, 150, 50, 30);

        b5.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                int res = Integer.parseInt(t1.getText()) - Integer.parseInt(t2.getText());

                t3.setText(String.valueOf(res));

            }
        });
        f.add(l1);
        f.add(l2);
        f.add(b1);
        f.add(b2);
        f.add(b3);
        f.add(b4);
        f.add(b5);
        f.add(t1);
        f.add(t2);
        f.add(t3);
        f.add(l3);
        f.setSize(500, 500);
        f.setLayout(null);
        f.setResizable(false);
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        f.setLocationRelativeTo(null);
        f.getContentPane().setBackground(Color.cyan);
        f.setVisible(true);

    }
}
