class WeekDay {
    int number;
    String name;
}

public class Example {
    public static void main(String[] args) {
        WeekDay day = new WeekDay();
        day.number = 1;
        day.name = "Sunday";
        System.out.println(day.number);
        System.out.println(day.name);
    }
}