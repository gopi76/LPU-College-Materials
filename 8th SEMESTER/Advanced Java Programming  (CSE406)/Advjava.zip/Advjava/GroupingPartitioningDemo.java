import java.util.*;
import java.util.stream.*;
import java.util.stream.Collectors;

class GroupingPartitioningDemo
{
public static void main(String [] args){
ArrayList<Employees> al = new ArrayList<>();
al.add(new Employees("Venkat","Hyderabad",false));
al.add(new Employees("sai","Hyderabad",true));
al.add(new Employees("tharun","Andhra",false));
al.add(new Employees("Guna","Nigeria",true));
al.add(new Employees("raviteja","Rajamandry",true));
al.add(new Employees("harsha","Andhra",true));
al.add(new Employees("Abhi","Delhi",true));

//Find the employees state wise

Map<String,List<Employees>> mp = al.stream().collect(Collectors.groupingBy(e->e.state));

Set<String> keys = mp.keySet();
for(String k:keys)
{
List <Employees> l = mp.get(k);
System.out.println("\nEmployees From "+k);
for(Employees e:l)
System.out.println(e.name +"\t"+ e.state);

}

// Use partitioning based on Martial Status

Map<Boolean,List<Employees>> mp1 = al.stream().collect(Collectors.partitioningBy(e->e.martial));
Set<Boolean> ks = mp1.keySet();
for(Boolean k: ks){
if(k)
System.out.println("\n\nMarried Employees are \n");
else
System.out.println("\n\nUnmarried Employees are \n");
List<Employees> l = mp1.get(k);
for(Employees e:l)
System.out.println(e.name + "\t" +e.state);

}




}
}

class Employees{
String name, state;
boolean martial;

Employees(String name, String state, boolean martial) {
this.name = name;
this.state = state;
this.martial = martial;
}
}

