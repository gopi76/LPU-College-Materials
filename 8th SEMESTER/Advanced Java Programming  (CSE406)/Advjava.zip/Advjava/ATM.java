import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
public class ATM extends JFrame implements ActionListener {
private JTextField accountNumberField;
private JPasswordField pinField;
private JButton loginButton;
private JButton depositButton;
private JButton withdrawButton;
private JButton balanceButton;
private JButton exitButton;
private Account account;
public ATM() {
super("ATM Simulator");
accountNumberField = new JTextField(10);
pinField = new JPasswordField(10);
loginButton = new JButton("Login");
depositButton = new JButton("Deposit");
withdrawButton = new JButton("Withdraw");
balanceButton = new JButton("Balance");
exitButton = new JButton("Exit");
loginButton.addActionListener(this);
depositButton.addActionListener(this);
withdrawButton.addActionListener(this);
balanceButton.addActionListener(this);
exitButton.addActionListener(this);
JPanel panel = new JPanel(new GridBagLayout());
GridBagConstraints constraints = new GridBagConstraints();
constraints.gridx = 0;
constraints.gridy = 0;
panel.add(new JLabel("Account Number:"), constraints);
constraints.gridx = 1;
constraints.gridy = 0;
panel.add(accountNumberField, constraints);
constraints.gridx = 0;
constraints.gridy = 1;
panel.add(new JLabel("PIN:"), constraints);
constraints.gridx = 1;
constraints.gridy = 1;
panel.add(pinField, constraints);
constraints.gridx = 0;
constraints.gridy = 2;
panel.add(loginButton, constraints);
constraints.gridx = 0;
constraints.gridy = 3;
panel.add(depositButton, constraints);
constraints.gridx = 1;
constraints.gridy = 3;
panel.add(withdrawButton, constraints);
constraints.gridx = 0;
constraints.gridy = 4;
panel.add(balanceButton, constraints);
constraints.gridx = 1;
constraints.gridy = 4;
panel.add(exitButton, constraints);
add(panel);
pack();
setVisible(true);
}
@Override
public void actionPerformed(ActionEvent e) {
if (e.getSource() == loginButton) {
String accountNumber = accountNumberField.getText();
String pin = pinField.getText();
account = Account.getAccount(accountNumber, pin);
if (account != null) {
JOptionPane.showMessageDialog(this, "Login successful!");
} else {
JOptionPane.showMessageDialog(this, "Invalid account number or PIN.");
}
} else if (e.getSource() == depositButton) {
if (account != null) {
double amount = Double.parseDouble(JOptionPane.showInputDialog(this, "Enter amount to deposit:"));
account.deposit(amount);
JOptionPane.showMessageDialog(this, "Deposit successful!");
} else {
JOptionPane.showMessageDialog(this, "Please login first.");
}
} else if (e.getSource() == withdrawButton) {
if (account != null) {
double amount = Double.parseDouble(JOptionPane.showInputDialog(this, "Enter amount to withdraw:"));
if (account.getBalance() >= amount) {
account.withdraw(amount);
JOptionPane.showMessageDialog(this, "Withdrawal successful!");
} else {
JOptionPane.showMessageDialog(this, "Insufficient balance.");
}
} else {
JOptionPane.showMessageDialog(this, "Please login first.");
}
} else if (e.getSource() == balanceButton) {
if (account != null) {
JOptionPane.showMessageDialog(this, "Your balance is: " + account.getBalance());
} else {
JOptionPane.showMessageDialog(this, "Please login first.");
}
} else if (e.getSource() == exitButton) {
System.exit(0);
}
}
public static void main(String[] args) {
new ATM();
}
}
class Account {
private String accountNumber;
private String pin;
private double balance;
public Account(String accountNumber, String pin, double balance)