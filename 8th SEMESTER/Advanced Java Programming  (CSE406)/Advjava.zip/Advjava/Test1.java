public class Test1{
public static void main(int[] venk){
System.out.println(venk);
}
}