import java.util.*;
import java.util.stream.*;
import java.util.List;
import java.util.Arrays;

class teacher {
    String name;
    int score;

    teacher(String name, int score) {
        this.name = name;
        this.score = score;
    }

    public String getName() {

        return this.name;
    }

    public int getScore() {
        return this.score;
    }
}

class ParallelandSeqential {
    public static void main(String... args) {
        System.out.println("-------Sequential Stream------");
        IntStream s = IntStream.rangeClosed(1, 10);
        s.forEach(System.out::println);

        System.out.println("-------Parallel Stream------");
        IntStream s1 = IntStream.rangeClosed(1, 10);
        s1.parallel().forEach(System.out::println);

        List<teacher> ls = Arrays.asList(
                new teacher("venkat", 45),
                new teacher("vinay", 87),
                new teacher("sai", 56),
                new teacher("ram", 98),
                new teacher("tharun", 45),
                new teacher("varun", 23),
                new teacher("abhi", 65),
                new teacher("guna", 89),
                new teacher("suhas", 58),
                new teacher("nithin", 72));
        System.out.println("-------Sequential Collection Stream------");
        Stream<teacher> str = ls.stream().filter(y -> y.getScore() > 50);
        str.forEach(y -> System.out.println(y.getName() + "\t" + y.getScore()));

        System.out.println("-------Parallel Collection Stream------");
        Stream<teacher> str1 = ls.parallelStream().filter(z -> z.getScore() > 50);
        str1.forEach(z -> System.out.println(z.getName() + "\t" + z.getScore()));

        System.out.println("-------Sequential to Parallel Converstion Collection Stream------");
        Stream<teacher> str2 = ls.stream().parallel().filter(x -> x.getScore() > 50).limit(3);
        str2.forEach(x -> System.out.println(x.getName() + "\t" + x.getScore()));

    }
}