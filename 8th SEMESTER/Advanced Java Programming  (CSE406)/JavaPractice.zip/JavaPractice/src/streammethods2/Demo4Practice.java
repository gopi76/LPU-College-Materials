package streammethods2;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;


public class Demo4Practice {
    public static void main(String[] args){
        List<String> animalList = Arrays.asList("Cat", "Dog", "Lion");
        List<String> birdList = Arrays.asList("Parrot", "Peacock", "Swift");
        
        Stream<String> stream1 = animalList.stream();
        Stream<String> stream2 = birdList.stream();
        
        List<String> concated = Stream.concat(stream1, stream2).collect(Collectors.toList());
        System.out.println(concated);
    }
    
}
