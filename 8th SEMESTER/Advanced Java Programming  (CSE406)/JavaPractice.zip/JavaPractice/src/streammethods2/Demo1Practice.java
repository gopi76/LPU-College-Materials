package streammethods2;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;
import java.util.Comparator;

public class Demo1Practice {
    public static void main(String[] args){
        List<Integer> numberList = Arrays.asList(1, 2, 3, 4, 5, 6, 7, 8, 9, 10);
        
        List<Integer> sortedList1 = numberList.stream().sorted().collect(Collectors.toList());
        System.out.println(sortedList1);
        
        List<Integer> sortedList2 = numberList.stream().sorted(Comparator.reverseOrder()).collect(Collectors.toList());
        System.out.println(sortedList2);
        
        List<String> namesList = Arrays.asList("Lithin", "Naga", "Datta", "Sravan", "Sunkara");
        
        List<String> sortedList3 = namesList.stream().sorted().collect(Collectors.toList());
        System.out.println(sortedList3);
        
        List<String> sortedList4 = namesList.stream().sorted(Comparator.reverseOrder()).collect(Collectors.toList());
        System.out.println(sortedList4);
    }
}
