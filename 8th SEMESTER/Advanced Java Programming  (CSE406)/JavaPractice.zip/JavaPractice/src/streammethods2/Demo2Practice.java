package streammethods2;

import java.util.List;
import java.util.Arrays;

public class Demo2Practice {
    public static void main(String[] args){
        List<String> names = Arrays.asList("sunkara", "lithin", "naga", "datta", "sravan");
        
        boolean result1 = names.stream().anyMatch(val -> {
            return val.startsWith("s");
        });
        System.out.println(result1);
        
        
        boolean result2 = names.stream().allMatch(val -> {
            return val.startsWith("s");
        });
        System.out.println(result2);
        
        boolean result3 = names.stream().noneMatch(val -> {
            return val.startsWith("b");
        });
        System.out.println(result3);
    } 
}
