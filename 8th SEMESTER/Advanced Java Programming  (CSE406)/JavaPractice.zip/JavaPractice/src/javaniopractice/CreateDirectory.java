package javaniopractice;

import java.nio.file.*;
import java.nio.*;


public class CreateDirectory {
    public static void main(String[] args){
        try{
            Path p = Paths.get("MoveDirectory");
            
            if(Files.exists(p)){
                System.out.println("Directory already created");
            } else {
                Path donePath = Files.createDirectory(p);
                System.out.println("Directory created successfully");
            }
        }
        catch(Exception e){
            System.out.println(e);
        }
    }
    
}
