package javaniopractice;

import java.nio.file.*;
import java.util.List;

public class ReadFromFile {
    public static void main(String[] args){
        try{
            Path p = Paths.get("Directory/sample.txt");
            
            List<String> data = Files.readAllLines(p);
            
            for(String str : data){
                System.out.println(str);
            }
        }
        catch(Exception e){
            System.out.println(e);
        }
    }
}
