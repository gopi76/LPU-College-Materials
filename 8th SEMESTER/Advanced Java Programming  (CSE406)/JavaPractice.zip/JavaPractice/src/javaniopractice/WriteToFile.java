package javaniopractice;

import java.nio.file.*;

public class WriteToFile {
    public static void main(String[] args){
        try{
           Path p = Paths.get("Directory/sample.txt");
           String data = "This is a sample file";
           Files.write(p, data.getBytes());
           System.out.println("Data written Successfully");
        }
        catch(Exception e){
            System.out.println(e);
        }
    }
}
