package javaniopractice;

import java.nio.file.*;

public class CopyFile {
    public static void main(String[] args){
        try{
            Path source = Paths.get("Directory/sample.txt");
            Path destination = Paths.get("DataSet/sampleCopied.txt");
            
            Files.copy(source, destination);
            System.out.println("File copied successfully");
        }
        catch(Exception e){
          System.out.println(e);  
        }
    }
    
}
