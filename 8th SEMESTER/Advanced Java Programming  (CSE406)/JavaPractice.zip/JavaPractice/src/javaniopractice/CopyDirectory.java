package javaniopractice;

import java.nio.file.*;
import java.nio.*;

public class CopyDirectory {
    public static void main(String[] args){
        try{
            Path source = Paths.get("Directory");
            Path destination = Paths.get("DataSet/Directory");
            
            Files.copy(source, destination);
            
        }
        catch(Exception e){
            System.out.println(e);
        }
    }
    
}
