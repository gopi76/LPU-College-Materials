package javaniopractice;

import java.nio.file.*;
import java.nio.*;

public class MoveDirectory {
    public static void main(String[] args){
        try{
            Path source = Paths.get("MoveDirectory");
            Path destination = Paths.get("DataSet/MoveDirectory");
            
            Files.move(source, destination);
            System.out.println("Directory successfully moved");
        }
        catch(Exception e){
            System.out.println(e);
        }
    }
}
