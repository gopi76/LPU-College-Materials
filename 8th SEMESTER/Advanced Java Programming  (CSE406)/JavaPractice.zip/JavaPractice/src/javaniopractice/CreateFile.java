package javaniopractice;

import java.nio.file.*;

public class CreateFile {
    public static void main(String[] args){
        try{
            Path p = Paths.get("Directory/sample.txt");
            if(Files.exists(p)){
                System.out.println("File already exists");
            } else {
                Path donePath = Files.createFile(p);
                System.out.println("File created Successfully");
            }
        } catch(Exception e){
            System.out.println(e);
        }
    }
}
