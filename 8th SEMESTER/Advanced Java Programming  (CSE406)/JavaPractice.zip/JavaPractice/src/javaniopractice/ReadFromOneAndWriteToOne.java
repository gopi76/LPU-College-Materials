package javaniopractice;

import java.nio.file.*;
import java.util.*;

public class ReadFromOneAndWriteToOne {
    public static void main(String[] args){
        try{
            Path p = Paths.get("Directory/sample.txt");
            List<String> data = Files.readAllLines(p);
            
            Path p2 = Paths.get("Directory/sampleCopied.txt");
            Files.write(p2, data);
            System.out.println("Data from one file copied to another");
        }
        catch(Exception e){
            System.out.println(e);
        }
    }
}
