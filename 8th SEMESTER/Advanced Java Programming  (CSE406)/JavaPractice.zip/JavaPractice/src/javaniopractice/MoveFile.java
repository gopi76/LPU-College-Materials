package javaniopractice;

import java.nio.file.*;

public class MoveFile {
    public static void main(String[] args){
        try{
            Path source = Paths.get("DataSet/sampleCopied.txt");
            Path destination = Paths.get("Directory/sampleCopied.txt");
            
            Files.move(source, destination);
            System.out.println("File moved Successfully");
        }
        catch(Exception e){
            System.out.println(e);
        }
    }
    
}
