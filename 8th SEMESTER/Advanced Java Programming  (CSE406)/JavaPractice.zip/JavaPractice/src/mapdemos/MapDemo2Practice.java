package mapdemos;

import java.util.Arrays;
import java.util.List;

public class MapDemo2Practice {
    public static void main(String[] args){
        List<String> names = Arrays.asList("car", "bike", "plane");
        
        names.stream().map(str -> str.charAt(0)).forEach(System.out::println);
    }
}
