package mapdemos;

import java.util.Arrays;
import java.util.List;

class Employees{
    int id;
    String name;
    
    public Employees(int id, String name){
        this.id = id;
        this.name = name;
    }
}
public class MapDemo3Practice {
    public static void main(String[] args){
        List<Employees> names = Arrays.asList(
                new Employees(1, "sravan"),
                new Employees(2, "lithin"),
                new Employees(3, "sunkara")
        );
        
        names.stream().filter(str -> str.id > 1).map(str -> str.name.toUpperCase()).forEach(System.out::println);
    }
}
