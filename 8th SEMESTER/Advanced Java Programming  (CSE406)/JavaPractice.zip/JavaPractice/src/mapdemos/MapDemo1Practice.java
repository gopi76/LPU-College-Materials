package mapdemos;

import java.util.Arrays;
import java.util.List;

public class MapDemo1Practice {
    public static void main(String[] args){
        List<String> names = Arrays.asList("sravan", "sunkara");
        
        names.stream().map(str -> str.toUpperCase()).forEach(System.out::println);
    }
}
