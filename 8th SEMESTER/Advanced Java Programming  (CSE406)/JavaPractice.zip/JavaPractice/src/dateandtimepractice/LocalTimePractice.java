package dateandtimepractice;

import java.time.*;
import java.time.format.DateTimeFormatter;

public class LocalTimePractice {
    public static void main(String[] args){
        LocalTime now = LocalTime.now();
        System.out.println(now);
        
        DateTimeFormatter fr = DateTimeFormatter.ofPattern("hh:mm");
        System.out.println(fr.format(now));
        
        LocalTime time = LocalTime.now().withHour(5);
        System.out.println(time);
        
        
    }
}
