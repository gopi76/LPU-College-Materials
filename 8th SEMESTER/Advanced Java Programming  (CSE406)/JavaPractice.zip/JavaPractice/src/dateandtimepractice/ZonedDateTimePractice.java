package dateandtimepractice;

import java.time.*;
import java.util.Set;

public class ZonedDateTimePractice {
    public static void main(String[] args){
        ZonedDateTime now = ZonedDateTime.now();
        System.out.println(now.getZone());
        
        Set<String> zoneids = ZoneId.getAvailableZoneIds();
        zoneids.stream().forEach(System.out::println);
    }
}
