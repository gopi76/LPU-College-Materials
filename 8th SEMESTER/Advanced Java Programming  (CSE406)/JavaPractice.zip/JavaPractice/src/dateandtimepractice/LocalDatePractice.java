package dateandtimepractice;

import java.time.*;;
import java.time.format.DateTimeFormatter;
import java.util.Locale;
import java.util.stream.Stream;

public class LocalDatePractice {
    public static void main(String[] args){
        LocalDate now = LocalDate.now();
        System.out.println(now);
        
        DateTimeFormatter fr = DateTimeFormatter.ofPattern("dd-MM-yy");
        String date = fr.format(now);
        System.out.println(date);
        
        LocalDate parse = LocalDate.of(2024,5,30);
        
        Month month = Month.of(5);
        System.out.println(month.length(true));
        int monthLength = month.length(true);
        
//        System.out.println(now.datesUntil(parse)
//                .filter(x -> x.getDayOfWeek() != x.getDayOfWeek().SUNDAY).count());
//                .forEach(System.out::println);
//        while(parse.getDayOfWeek() == parse.getDayOfWeek().SUNDAY){
//            now.datesUntil(parse);
//        }
        now.datesUntil(parse)
                .filter(x -> x.getDayOfWeek() != x.getDayOfWeek().SUNDAY)
                .forEach(x -> System.out.println(x));
        
    }
}
