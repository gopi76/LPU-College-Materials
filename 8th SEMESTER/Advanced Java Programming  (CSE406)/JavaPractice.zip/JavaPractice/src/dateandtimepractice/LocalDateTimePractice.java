package dateandtimepractice;

import java.time.*;

public class LocalDateTimePractice {
    public static void main(String[] args){
        LocalDateTime now = LocalDateTime.now();
        LocalDateTime parse = LocalDateTime.parse("2024-05-02T11:45:21");
        System.out.println(parse);
        
    }
    
}
