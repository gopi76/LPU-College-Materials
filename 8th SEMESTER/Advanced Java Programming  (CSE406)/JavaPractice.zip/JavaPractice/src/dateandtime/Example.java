package dateandtime;

import java.util.*;
import java.time.*;
import java.time.format.*;
import java.time.temporal.TemporalAdjusters;

public class Example {
    public static void main(String[] rk){
        Scanner sc = new Scanner(System.in);
        String dt = sc.nextLine();
        LocalDate date = LocalDate.parse(dt);
        Month month = date.getMonth();
        int year = date.getYear();
        
        LocalDate firstDayOfMonth = LocalDate.of(year, month, 1);
        LocalDate lastDayOfMonth = firstDayOfMonth.with(TemporalAdjusters.lastDayOfMonth());
        
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");
        
        System.out.println("Holidays in " + month + " " + year +":");
        
        LocalDate currentDay = firstDayOfMonth;
        while(!currentDay.isAfter(lastDayOfMonth)){
            DayOfWeek dayOfWeek = currentDay.getDayOfWeek();
            int dayOfMonth = currentDay.getDayOfMonth();
            
            if (dayOfWeek == DayOfWeek.SUNDAY || (dayOfWeek == DayOfWeek.SATURDAY && (dayOfMonth == 2 || dayOfMonth == 4))) {
                System.out.println(formatter.format(currentDay));
            }
        }
    }
}

