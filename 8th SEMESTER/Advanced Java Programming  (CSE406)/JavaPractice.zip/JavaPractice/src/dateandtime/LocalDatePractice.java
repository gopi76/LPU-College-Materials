package dateandtime;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.Month;

public class LocalDatePractice {
    public static void main(String[] args){
        LocalDate today = LocalDate.now();
        System.out.println("Today: "+today);
        
        LocalDate customDate = LocalDate.of(2024,2,4);
        System.out.println("Custom date: "+customDate);
        
        DayOfWeek dayOfWeek = today.getDayOfWeek();
        System.out.println("Day of week: "+dayOfWeek);
        
        int dayOfMonth = today.getDayOfMonth();
        System.out.println("Day of month: "+dayOfMonth);
        
        Month month = today.getMonth();
        System.out.println("Month: "+month);
        
        int monthNumber = today.getMonthValue();
        System.out.println("Month number: "+monthNumber);
        
        int year = today.getYear();
        System.out.println("Year: "+year);
        
        LocalDate yesterday = today.minusDays(1);
        System.out.println("Yesterday: "+yesterday);
        
        LocalDate pastWeek = today.minusWeeks(2);
        System.out.println("Past day in the week: "+pastWeek);
        
        LocalDate pastMonth = today.minusMonths(2);
        System.out.println("Past day in the month: "+pastMonth);
        
        LocalDate pastYear = today.minusYears(2);
        System.out.println("Past day in the year: "+pastYear);
        
        System.out.println(today.getDayOfWeek());
        
        LocalDate parsed = LocalDate.parse("2024-04-22");
        System.out.println("Parsed Date: "+parsed);
        
        if(today.isAfter(yesterday)){
            System.out.println("yes");
        }
    }
}
