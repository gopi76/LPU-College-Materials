package dateandtime;

import java.time.LocalDateTime;

public class LocalDateTimePractice {
    public static void main(String[] args){
        LocalDateTime todayNow = LocalDateTime.now();
        System.out.println(todayNow);
        
        LocalDateTime myDate = LocalDateTime.parse("2024-04-09T13:48");
        System.out.println(myDate);
    }
}
