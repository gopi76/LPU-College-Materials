package dateandtime;

import java.time.ZonedDateTime;

public class ZonedDateTimePractice {
    public static void main(String[] args){
        ZonedDateTime now = ZonedDateTime.now();
        System.out.println(now.getZone());
        
        System.out.println(now);
    }
}
