package flatmapdemos;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

class Students{
    String name;
    int id;
    char grade;
    
    public Students(String name, int id, char grade){
        this.name = name;
        this.id = id;
        this.grade = grade; 
    }
}

public class FlatmapDemo3Practice {
    public static void main(String[] args){
        List<Students> list1 = new ArrayList<>();
        list1.add(new Students("Sravan", 1, 'A'));
        list1.add(new Students("Datthu", 2, 'A'));
        list1.add(new Students("Lithin", 3, 'A'));
        
        List<Students> list2 = new ArrayList<>();
        list1.add(new Students("Naga", 4, 'A'));
        list1.add(new Students("Datta", 5, 'A'));
        list1.add(new Students("Sunkara", 6, 'A'));
        
        List<List<Students>> studentLists = Arrays.asList(list1, list2);
        studentLists.stream().flatMap(str -> str.stream()).forEach(str -> System.out.println(str.name));
    }
}
