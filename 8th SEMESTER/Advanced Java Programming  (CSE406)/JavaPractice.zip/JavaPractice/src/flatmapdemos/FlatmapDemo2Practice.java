package flatmapdemos;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class FlatmapDemo2Practice {
    public static void main(String[] args){
        List<String> teamA = Arrays.asList("Lithin", "Naga");
        List<String> teamB = Arrays.asList("Datta", "Sravan");
        List<String> teamC = Arrays.asList("Sunkara", "Datthu");
        
        List<List<String>> finalList = new ArrayList<>();
        finalList.add(teamA);
        finalList.add(teamB);
        finalList.add(teamC);
        
        finalList.stream().flatMap(x -> x.stream()).forEach(System.out::println);
    }
    
}
