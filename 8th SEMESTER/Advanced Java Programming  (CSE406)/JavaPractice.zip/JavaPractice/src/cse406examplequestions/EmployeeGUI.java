package cse406examplequestions;

//WAP to design a GUI which reads the EMP_ID of an Employee and prints the work experience of the 
//employee along with employee name and salary
//Also display the current date and day on the top RIGHT corner of the Frame
//Use JDBC to fetch the details of employee from EMP table where name, id, salary and Date of 
//joining is stored.


import java.awt.*;
import java.awt.event.ActionEvent;
import javax.swing.*;
import java.sql.*;
import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;

public class EmployeeGUI {
    public static void main(String[] args){
        JFrame frame = new JFrame("Employee Portal");
        
        LocalDate now2 = LocalDate.now();
        DateTimeFormatter fr = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        
        JLabel dateLabel = new JLabel(fr.format(now2));
        dateLabel.setBounds(300, 100, 50, 50);
        frame.add(dateLabel);
        
        GridBagLayout gb = new GridBagLayout();
        GridBagConstraints gbc = new GridBagConstraints();
        frame.setLayout(gb);
        gbc.insets = new Insets(5, 5, 5, 5);
        
        JLabel idLabel = new JLabel("ID");
        gbc.gridx = 1;
        gbc.gridy = 1;
        frame.add(idLabel, gbc);
        
        JTextField idField = new JTextField(10);
        gbc.gridx = 2;
        gbc.gridy = 1;
        frame.add(idField, gbc);
        
        JButton submit = new JButton("submit");
        gbc.gridx = 3;
        gbc.gridy = 1;
        frame.add(submit, gbc);
        
        submit.addActionListener((ActionEvent e) ->{
            String id = idField.getText();
            String eName = "";
            String eSalary = "";
            String eDate = "";
            
            try{
                Class.forName("com.mysql.cj.jdbc.Driver");
                Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/students", "root", "2002");
                PreparedStatement ps = connection.prepareStatement("SELECT * FROM EMPLOYEES WHERE id=?");
                ps.setString(1, id);
                ResultSet rs = ps.executeQuery();
                while(rs.next()){
                    eName = rs.getString("name");
                    eSalary = rs.getString("salary");
                    eDate = rs.getString("doj");
                }
                connection.close();
            }
            catch(Exception ex){
                System.out.println(ex);
            }
            
            LocalDate parsed = LocalDate.parse(eDate);
            LocalDate now = LocalDate.now();
            Period period = Period.between(parsed, now);
            
            String experience = period.getYears() + " Year " + period.getMonths() + " Months";
            
            JLabel nameLabel = new JLabel("Name: " + eName);
            gbc.gridx = 1;
            gbc.gridy = 3;
            frame.add(nameLabel, gbc);
            
            JLabel salaryLabel = new JLabel("Salary: "+eSalary);
            gbc.gridx = 2;
            gbc.gridy = 3;
            frame.add(salaryLabel, gbc);
            
            JLabel experienceLabel = new JLabel("Experience: "+experience);
            gbc.gridx = 3;
            gbc.gridy = 3;
            frame.add(experienceLabel, gbc);
            
            frame.revalidate();
            frame.repaint();
        });
        
        frame.setSize(400, 400);
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
        frame.setDefaultCloseOperation(frame.EXIT_ON_CLOSE);
    }
}
