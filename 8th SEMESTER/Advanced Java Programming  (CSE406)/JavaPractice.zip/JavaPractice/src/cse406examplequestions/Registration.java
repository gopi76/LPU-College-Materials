package cse406examplequestions;

class BuilderDemo {
    public static void main(String[] rk) {
        Registration obj =
                new Registration.Builder("Ravi Kant Sahu", "er.ravikantsahu")
                        .setMobile(89277)
                        .build();

        Registration obj2 =
                new Registration.Builder("Ravi Shanker", "shanker.ravi")
                        .setAge(21)
                        .build();

        System.out.println(obj.getName() + "\t" + obj.getEmail() + "\t" + obj.getAge() + "\t" + obj.getMobile());
        System.out.println(obj2.getName() + "\t" + obj2.getEmail() + "\t" + obj2.getAge() + "\t" + obj2.getMobile());

    }
}

class Registration {
    private String name, email; //Compulsory
    private int age, mobile;

    private Registration(Builder b) {
        this.name = b.name;
        this.email = b.email;
        this.age = b.age;
        this.mobile = b.mobile;
    }

    // Provide getter methods for all the attributes here...
    public String getName() {
        return name;
    }

    public String getEmail() {
        return email;
    }

    public int getAge() {
        return age;
    }

    public int getMobile() {
        return mobile;
    }

    static public class Builder {
        private String name, email; //Compulsory
        private int age, mobile;

        public Builder(String name, String mail) {
            this.name = name;
            this.email = mail;
        }

        public Builder setAge(int a) {
            this.age = a;
            return this;
        }

        public Builder setMobile(int m) {
            this.mobile = m;
            return this;
        }

        public Registration build() {
            Registration ob = new Registration(this);
            return ob;
        }
    }
}
