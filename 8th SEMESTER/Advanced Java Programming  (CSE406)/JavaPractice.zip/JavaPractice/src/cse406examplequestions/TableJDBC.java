package cse406examplequestions;

//Write a program which reads the table name from the user as command line argument 
//and prints all the data of that table using the resultsetmetadata in JDBC

import java.sql.*;
import java.util.Scanner;

public class TableJDBC {
    public static void main(String[] args){
        Scanner input = new Scanner(System.in);
        System.out.print("Enter table name: ");
        String tableName = input.nextLine();
        try{
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/class", "root", "2002");
            Statement statement = connection.createStatement();
            ResultSet rs = statement.executeQuery("SELECT * FROM "+tableName);
            ResultSetMetaData metaData = rs.getMetaData();
            
            int columnCount = metaData.getColumnCount();
            for(int i=1; i<=columnCount; i++){
                System.out.print(metaData.getColumnName(i)+" ");
            }
            System.out.println();
            
            while (rs.next()) {
                for (int i = 1; i <= columnCount; i++) {
                    System.out.print(rs.getString(i) + "\t");
                }
                System.out.println();
            }

        }
        catch(Exception e){
            System.out.println(e);
        }
    }
    
}
