package cse406examplequestions;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;
import java.util.stream.Collectors;


public class Practice {
    String name;
    double cgpa;
    String place;
    
    public Practice(String name, double cgpa, String place){
        this.name = name;
        this.cgpa = cgpa;
        this.place = place;
    }
    
    public static void main(String[] args){
        ArrayList<Practice> details = new ArrayList<>();
        details.add(new Practice("Sravan", 9.5, "Palakol"));
        details.add(new Practice("Lithin", 8.5, "Bhimavaram"));
        details.add(new Practice("Datta", 9.2, "Narasapuram"));
        details.add(new Practice("Sunkara", 8.3, "Koderu"));
        details.add(new Practice("Datthu", 7.9, "Palakol"));
        details.add(new Practice("Honey", 8.9, "Palakol"));
        details.add(new Practice("Srinu", 9.8, "Koderu"));
        
//        List<Practice> sortedList = details.stream().sorted((b, a)->a.name.compareTo(b.name)).collect(Collectors.toList());
//        for(Practice p: sortedList){
//            System.out.println(p.name +" "+ p.cgpa +" "+ p.place);
//        }
//        
//        System.out.println();
//        
//        Set<Practice> sortedList2 = details.stream().sorted((b, a)->a.name.compareTo(b.name)).collect(Collectors.toSet());
//        for(Practice p: sortedList2){
//            System.out.println(p.name +" "+ p.cgpa +" "+ p.place);
//        }
        
//        Map<String, List<Practice>> map = details.stream().collect(Collectors.groupingBy(x -> x.place));
//        
//        System.out.print("Enter the state: ");
//        Scanner input = new Scanner(System.in);
//        String state = input.next();
//        List<Practice> ls = map.get(state);
//        for(Practice p : ls){
//            System.out.println(p.name +" "+ p.cgpa +" "+ p.place);
//        }
        
        Map<Boolean, List<Practice>> mp = details.stream().collect(Collectors.partitioningBy(x -> x.cgpa > 8.5));
        List<Practice> ls1 = mp.get(true);
        for(Practice p : ls1){
            System.out.println(p.name +" "+ p.cgpa +" "+ p.place);
        }
        System.out.println();
        List<Practice> ls2 = mp.get(false);
        for(Practice p : ls2){
            System.out.println(p.name +" "+ p.cgpa +" "+ p.place);
        }
        
    }
}
