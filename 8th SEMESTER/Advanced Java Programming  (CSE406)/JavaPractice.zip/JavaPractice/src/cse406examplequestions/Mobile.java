package cse406examplequestions;

//Define a class Mobile with attributes model_name, price, and Brand.
//Store atleast 5 mobile Objects in an ArrayList.
//Use Stream API to group all the mobile objects based on Brand using groupingBy().
//Ask the user to enter the brand and display all the mobiles of that brand in the 
//sorted order of their price

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.stream.Collectors;

public class Mobile {
    String model_name;
    int price;
    String brand;
    
    public Mobile(String model_name, int price, String brand){
        this.model_name = model_name;
        this.price = price;
        this.brand = brand;
    }
    
    public static void main(String[] args){
        ArrayList<Mobile> mobiles = new ArrayList<>();
        mobiles.add(new Mobile("a1", 20000, "redmi"));
        mobiles.add(new Mobile("s2", 30000, "samsung"));
        mobiles.add(new Mobile("s0", 15000, "samsung"));
        mobiles.add(new Mobile("s1", 25000, "samsung"));
        mobiles.add(new Mobile("x1", 200000, "apple"));
        mobiles.add(new Mobile("op1", 60000, "oneplus"));
        mobiles.add(new Mobile("a2", 40000, "redmi"));
        mobiles.add(new Mobile("x1pro", 350000, "apple"));
        
        //Grouping By
        Map<String, List<Mobile>> map = mobiles.stream().collect(Collectors.groupingBy(x -> x.brand.toLowerCase()));
        
        Scanner input = new Scanner(System.in);
        System.out.print("Enter brand name: ");
        String brand = input.next().toLowerCase();
        
        List<Mobile> sortedList = map.get(brand);
        sortedList = sortedList.stream().sorted((a, b)-> Integer.compare(a.price, b.price)).collect(Collectors.toList());
        for(Mobile m : sortedList){
            System.out.println(m.model_name +" "+ m.price +" "+ m.brand);
        }
        
        //Partiontioning By
        Map<Boolean, List<Mobile>> map2 = mobiles.stream().collect(Collectors.partitioningBy(x -> x.price > 30000));
        
        System.out.println("Mobiles above 30,000 rupees");
        List<Mobile> ls1 = map2.get(true);
        for(Mobile m : ls1){
            System.out.println(m.model_name + " " + m.price + " " + m.brand);
        }
        
        System.out.println("Mobiles under 30,000 rupees");
        List<Mobile> ls2 = map2.get(false);
        for(Mobile m : ls2){
            System.out.println(m.model_name + " " + m.price + " " + m.brand);
        }
        
    }
}
