package cse406examplequestions;
//Use swing api to design a  "temperature converter" where provide JComboBox to select 
//the unit of input type, output type and textfield to read the value to be converted and 
//display the result in a non-edited field

import javax.swing.*;
import java.awt.event.ActionEvent;

public class TemperatureConverter {
    public static void main(String[] args){
        JFrame frame = new JFrame("temperature converter");
        
        String[] units = {"Celcius", "Fahrenheit"};
        JLabel input = new JLabel("Input");
        input.setBounds(100, 20, 30, 20);
        frame.add(input);
        
        JLabel output = new JLabel("Output");
        output.setBounds(100, 60, 40, 20);
        frame.add(output);
        
        JComboBox comboBox1 = new JComboBox(units);
        comboBox1.setBounds(180, 20, 80, 20);
        frame.add(comboBox1);
        
        JComboBox comboBox2 = new JComboBox(units);
        comboBox2.setBounds(180, 60, 80, 20);
        frame.add(comboBox2);
        
        JTextField inputField = new JTextField();
        inputField.setBounds(180, 100, 80, 20);
        frame.add(inputField);
        
        JButton submit = new JButton("submit");
        submit.setBounds(180, 140, 80, 20);
        frame.add(submit);
        
        
        submit.addActionListener((ActionEvent e)->{
            String text = inputField.getText();
            Double num = Double.valueOf(text);
            if(comboBox1.getSelectedIndex() == 0 && comboBox2.getSelectedIndex() == 1){
                num =  (num*9/5)+32;
            }else if(comboBox1.getSelectedIndex() == 1 && comboBox2.getSelectedIndex() == 0){
                num = (num-32)*5/9;
            }
            
            JLabel result = new JLabel(num+"");
            result.setBounds(180, 180, 40, 20);
            frame.add(result);
            
            frame.revalidate();
            frame.repaint();
        });
        
        frame.setSize(400, 400);
        frame.setLayout(null);
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
        frame.setDefaultCloseOperation(frame.EXIT_ON_CLOSE);
    }
}
