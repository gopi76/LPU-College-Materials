package cse406examplequestions;
//write a program to design a "TIMER" with buttons to start, pause and stop.
//Timer must show minutes, second and milliseconds


import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class TimerApplication extends JFrame {
    private JLabel timeLabel;
    private Timer timer;
    private boolean isRunning;

    public TimerApplication() {
        setTitle("Timer Application");
        setSize(300, 150);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        timeLabel = new JLabel("00:00:00");
        timeLabel.setHorizontalAlignment(JLabel.CENTER);
        timeLabel.setFont(new Font("Arial", Font.BOLD, 24));

        JPanel buttonPanel = new JPanel();
        JButton startButton = new JButton("Start");
        JButton pauseButton = new JButton("Pause");
        JButton stopButton = new JButton("Stop");

        startButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (!isRunning) {
                    isRunning = true;
                    startTimer();
                }
            }
        });

        pauseButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (isRunning) {
                    isRunning = false;
                    pauseTimer();
                }
            }
        });

        stopButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                isRunning = false;
                stopTimer();
            }
        });

        buttonPanel.add(startButton);
        buttonPanel.add(pauseButton);
        buttonPanel.add(stopButton);

        add(timeLabel, BorderLayout.CENTER);
        add(buttonPanel, BorderLayout.SOUTH);
    }

    private void startTimer() {
        timer = new Timer(1000, new ActionListener() {
            int seconds = 0;
            int minutes = 0;
            int hours = 0;

            @Override
            public void actionPerformed(ActionEvent e) {
                seconds++;
                if (seconds == 60) {
                    seconds = 0;
                    minutes++;
                    if (minutes == 60) {
                        minutes = 0;
                        hours++;
                    }
                }
                String timeString = String.format("%02d:%02d:%02d", hours, minutes, seconds);
                timeLabel.setText(timeString);
            }
        });
        timer.start();
    }

    private void pauseTimer() {
        timer.stop();
    }

    private void stopTimer() {
        timer.stop();
        timeLabel.setText("00:00:00");
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new TimerApplication().setVisible(true);
            }
        });
    }
}
