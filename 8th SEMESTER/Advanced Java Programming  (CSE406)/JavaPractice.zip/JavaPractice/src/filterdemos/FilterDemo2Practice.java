package filterdemos;

import java.util.Arrays;
import java.util.List;

public class FilterDemo2Practice {
    public static void main(String[] args){
        List<String> names = Arrays.asList("Sravan", "Sunkara", "Lithin");
        
        names.stream().filter(str -> str.length() > 5).forEach(System.out::println);
    }
}
