package filterdemos;

import java.util.ArrayList;
import java.util.List;

class Products{
    int id;
    String name;
    int price;
    
    public Products(int id, String name, int price){
        this.id = id;
        this.name = name;
        this.price = price;
    }
}

public class FilterDemo4Practice {
    public static void main(String[] args){
        List<Products> productsList = new ArrayList<>();
        productsList.add(new Products(1, "jimjam", 20));
        productsList.add(new Products(2, "oreo", 30));
        productsList.add(new Products(3, "gooday", 25));
        productsList.add(new Products(4, "sunfeast", 10));
        
        productsList.stream().filter(p -> p.price> 25).forEach(p -> System.out.println(p.id + " " + p.name + " " + p.price));
//        productsList.stream().filter(p -> p.price> 25).forEach(System.out::println);
    }
}
