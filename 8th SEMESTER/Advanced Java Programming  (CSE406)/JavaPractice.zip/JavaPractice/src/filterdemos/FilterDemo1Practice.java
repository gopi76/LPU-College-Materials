package filterdemos;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class FilterDemo1Practice {
    public static void main(String[] args){
        List<Integer> numberList = Arrays.asList(10, 15, 20, 30, 40, 50);
        
        ArrayList<Integer> evenNumberList = (ArrayList<Integer>)numberList.stream().filter(n -> n%2==0).collect(Collectors.toList());
        System.out.println(evenNumberList);
        
        List<Integer> evenNumbers = numberList.stream().filter(n -> n%2==0).collect(Collectors.toList());
        System.out.println(evenNumbers);
        
        numberList.stream().filter(n -> n%2==0).forEach(n -> System.out.print(n+" "));
    }
}
