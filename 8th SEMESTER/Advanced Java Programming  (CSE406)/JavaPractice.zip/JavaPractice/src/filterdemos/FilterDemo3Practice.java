package filterdemos;

import java.util.Arrays;
import java.util.List;

public class FilterDemo3Practice {
    public static void main(String[] args){
        List<String> names = Arrays.asList("Lithin", null, "Sravan", null);
        System.out.println(names.stream().count());
        
        names.stream().filter(str -> str!=null).forEach(System.out::println);
    }
}
