package combinedpractice;

import java.awt.event.*;
import java.util.Arrays;
import javax.swing.*;
import java.util.List;
import java.util.*;
import java.util.stream.Collectors;
import javax.swing.table.DefaultTableModel;
import java.sql.*;
import java.nio.file.*;

class StudentsGUI{
    String name;
    int id;
    String place;
    String gender;
    
    public StudentsGUI(String name, int id, String place, String gender){
        this.name = name;
        this.id = id;
        this.place = place;
        this.gender = gender;
    }
}

public class Practice4 extends JFrame implements ActionListener {
    JCheckBox cb;
    JRadioButton male, female;
    JMenuBar mb;
    JMenu file;
    JMenuItem savefile, savejdbc;
    JTextArea ta;
    
    List<StudentsGUI> details = Arrays.asList(
                new StudentsGUI("sravan", 1, "palakol", "male"),
                new StudentsGUI("srinu", 2, "koderu", "male"),
                new StudentsGUI("sailaja", 3, "palakol", "female"),
                new StudentsGUI("hyma", 4, "palakol", "female"),
                new StudentsGUI("annapoorna", 5, "koderu", "female"),
                new StudentsGUI("ramakrishna", 6, "koderu", "male"),
                new StudentsGUI("udaykiran", 7, "palakol", "male")
    );
    
    Practice4(){
        setSize(400, 400);
        setLayout(null);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        
        cb = new JCheckBox("Palakol");
        cb.setBounds(50, 40, 100, 50);
        cb.addActionListener(this);
        add(cb);
        
        male = new JRadioButton("male");
        male.setBounds(50, 80, 60, 40);
        male.addActionListener(this);
        add(male);
        
        female = new JRadioButton("female");
        female.setBounds(120, 80, 100, 40);
        female.addActionListener(this);
        add(female);
        
        ButtonGroup bg = new ButtonGroup();
        bg.add(male);
        bg.add(female);
        
        mb = new JMenuBar();
        file = new JMenu("File");
        mb.add(file);
        savefile = new JMenuItem("Save File");
        savefile.addActionListener(this);
        file.add(savefile);
        savejdbc = new JMenuItem("Save JDBC");
        savejdbc.addActionListener(this);
        file.add(savejdbc);
        setJMenuBar(mb);
        
        ta = new JTextArea();
        ta.setBounds(0, 0, 400, 40);
        add(ta);
        
        setVisible(true);
    }
    
    public void actionPerformed(ActionEvent e){
        Map<Boolean, List<StudentsGUI>> mp2 = details.stream().collect(Collectors.partitioningBy(x -> x.gender.equals("male")));
        if(cb.isSelected()){
            Map<String, List<StudentsGUI>> mp = details.stream().collect(Collectors.groupingBy(x -> x.place));
            List<StudentsGUI> place = mp.get("palakol");
            
            String[] columns = {"Name", "ID", "Place", "Gender"};
            DefaultTableModel model = new DefaultTableModel(columns, 0);
            JTable table = new JTable(model);
            JScrollPane pane = new JScrollPane(table);
            pane.setBounds(0, 120, 400, 200);
            add(pane);
            
            for(StudentsGUI s: place){
                model.addRow(new Object[]{s.name, s.id, s.place, s.gender});
            }
        } else if(e.getSource() == male){
            List<StudentsGUI> place = mp2.get(true);
            String[] columns = {"Name", "ID", "Place", "Gender"};
            DefaultTableModel model = new DefaultTableModel(columns, 0);
            JTable table = new JTable(model);
            JScrollPane pane = new JScrollPane(table);
            pane.setBounds(0, 120, 400, 200);
            add(pane);
            
            for(StudentsGUI s: place){
                model.addRow(new Object[]{s.name, s.id, s.place, s.gender});
            }
        } else if(e.getSource() == female){
            List<StudentsGUI> place = mp2.get(false);
            String[] columns = {"Name", "ID", "Place", "Gender"};
            DefaultTableModel model = new DefaultTableModel(columns, 0);
            JTable table = new JTable(model);
            JScrollPane pane = new JScrollPane(table);
            pane.setBounds(0, 120, 400, 200);
            add(pane);
            
            for(StudentsGUI s: place){
                model.addRow(new Object[]{s.name, s.id, s.place, s.gender});
            }
        } else if(e.getSource() == savejdbc){
            String text = ta.getText();
            try{
                Class.forName("com.mysql.cj.jdbc.Driver");
                Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/students", "root", "2002");
                PreparedStatement ps = con.prepareStatement("INSERT INTO textdata VALUES(?)");
                ps.setString(1, text);
                int i = ps.executeUpdate();
                if(i>0){
                    JOptionPane.showMessageDialog(null, "Successfully inserted into DataBase");
                }else{
                    JOptionPane.showMessageDialog(null, "Failed to insert into DataBase");
                }
                con.close();
            } catch(Exception sql){
                System.out.println(sql);
            }
        } else if(e.getSource() == savefile){
            String text = ta.getText();
            try{
                Path p = Paths.get("DataSet/practice4.txt");
                if(Files.exists(p)){
                    JOptionPane.showMessageDialog(null, "File already Created");
                } else {
                    Path donePath = Files.createFile(p);
                    Files.write(donePath, text.getBytes());
                    JOptionPane.showMessageDialog(null, "File Successfully created");
                }
            } catch(Exception files){
                System.out.println(files);
            }
        }
    }
    
    public static void main(String[] args){
        new Practice4();
    }
    
    
}
