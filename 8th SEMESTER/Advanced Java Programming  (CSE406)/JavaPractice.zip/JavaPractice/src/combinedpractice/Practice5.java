package combinedpractice;

import java.awt.Color;
import javax.swing.*;
import java.awt.event.*;

public class Practice5 extends JFrame implements ActionListener {
    
    Practice5(){
        setSize(400, 400);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(null);
        
        JPanel p1 = new JPanel();
        JPanel p2 = new JPanel();
        JTextArea ta = new JTextArea();
        p1.add(ta);
        p1.setBounds(10, 10, 200, 200);
        p1.setBackground(Color.red);
        add(p1);
        add(p2);
        
        JTabbedPane tb = new JTabbedPane();
        tb.add("main", p1);
        tb.add("sub", p2);
        tb.setBounds(10, 10, 200, 200);
        add(tb);
        
        setVisible(true);
    }
    
    public void actionPerformed(ActionEvent e){
        
    }
    
    public static void main(String[] args){
        new Practice5();
    }
}
