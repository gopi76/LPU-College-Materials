package combinedpractice;

import java.util.*;
import java.util.stream.Collectors;

class StudentStream{
    String name;
    int id;
    String place;
    String gender;
    
    public StudentStream(String name, int id, String place, String gender){
        this.name = name;
        this.id = id;
        this.place = place;
        this.gender = gender;
    }
}

public class Practice3 {
    public static void main(String[] args){
//        List<String> names = Arrays.asList("Sravan", "Lithin", "Naga", "Datta", "Sunkara");
//        names.stream().filter(x -> x.startsWith("S")).forEach(System.out::println);
//        names.stream().limit(2).forEach(System.out::println);
//        names.stream().map(x -> x.toUpperCase()).forEach(System.out::println);
//        Optional<String> reduced = names.stream().reduce((val1, val2)->{return val1+val2;});
//        System.out.println(reduced.get());
//        names.stream().sorted(Comparator.reverseOrder()).forEach(System.out::println);
//        names.stream().sorted((val1, val2) -> val1.compareTo(val2)).forEach(System.out::println);
//        List<Integer> numbers = Arrays.asList(1, 2, 3, 4, 5, 6, 7, 8, 9, 10);
//        numbers.stream().filter(x -> x%2==0).forEach(System.out::println);
//        numbers.stream().map(x -> x*2).forEach(System.out::println);
//        numbers.stream().limit(3).forEach(System.out::println);
//        Optional<Integer> reduced2 = numbers.stream().reduce((val1, val2)->{
//            return val1+val2;
//        });
//        System.out.println(reduced2.get());
//        numbers.stream().sorted(Comparator.reverseOrder()).forEach(System.out::println);

        List<StudentStream> details = Arrays.asList(
                new StudentStream("sravan", 1, "palakol", "male"),
                new StudentStream("srinu", 2, "koderu", "male"),
                new StudentStream("sailaja", 3, "palakol", "female"),
                new StudentStream("hyma", 4, "palakol", "female"),
                new StudentStream("annapoorna", 5, "koderu", "female"),
                new StudentStream("ramakrishna", 6, "koderu", "male"),
                new StudentStream("udaykiran", 7, "palakol", "male")
        );
        
//        details.stream().filter(x->x.id>=5).forEach(s-> System.out.println(s.name));
//        details.stream().filter(x->x.name.startsWith("s")).forEach(s-> System.out.println(s.name));
//        details.stream().map(x -> x.name.toUpperCase()).forEach(System.out::println);
//        Map<String, List<StudentStream>> mp = details.stream().collect(Collectors.groupingBy(x->x.place));
//        List<StudentStream> ls1 = mp.get("palakol");
//        for(StudentStream s : ls1){
//            System.out.println(s.name + " " + s.place);
//        }
        
//        Map<Boolean, List<StudentStream>> mp2 = details.stream().collect(Collectors.partitioningBy(x->x.gender.equals("male")));
//        List<StudentStream> ls2 = mp2.get(true);
//        for(StudentStream s : ls2){
//            System.out.println(s.name + " " + s.gender);
//        }
        
//        List<StudentStream> ls3 = mp2.get(false);
//        for(StudentStream s : ls3){
//            System.out.println(s.name + " " + s.gender);
//        }


        
    }
    
}
