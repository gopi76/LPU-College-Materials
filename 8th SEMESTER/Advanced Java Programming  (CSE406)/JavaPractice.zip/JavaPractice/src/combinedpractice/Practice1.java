package combinedpractice;

//streams + checkbox, combobox, radiobutton, table

import java.awt.event.ActionEvent;
import javax.swing.*;
import java.util.stream.Collectors;
import java.util.List;
import java.util.*;
import javax.swing.table.DefaultTableModel;

class StudentsList{
    String name;
    int id;
    String gender;
    String place;
    int total;
    
    public StudentsList(String name, int id, String gender, String place, int total){
        this.name = name;
        this.id = id;
        this.gender = gender;
        this.place = place;
        this.total = total;
    }
}

public class Practice1 {
    public static void main(String[] args){
        List<StudentsList> details = Arrays.asList(
                new StudentsList("Sravan", 1, "male", "palakol", 850),
                new StudentsList("Lithin", 2, "male", "palakol", 300),
                new StudentsList("Naga", 3, "male", "palakol", 400),
                new StudentsList("Datta", 4, "male", "palakol", 700),
                new StudentsList("Sunkara", 5, "male", "palakol", 900),
                new StudentsList("Honey", 6, "female", "hyderabad", 550),
                new StudentsList("Sailaja", 7, "female", "koderu", 660),
                new StudentsList("Annapurna", 8, "female", "palem", 720),
                new StudentsList("Devi", 9, "female", "palakol", 690),
                new StudentsList("Srinu", 10, "male", "koderu", 900)
        );
        
        JFrame frame = new JFrame("Combined");
        
        String[] sort = {"Ascending", "Descending"};
        JComboBox cb = new JComboBox(sort);
        cb.setBounds(100, 10, 100, 20);
        frame.add(cb);
        
        cb.addActionListener((ActionEvent e)->{
            if(cb.getSelectedIndex()==0){
                List<StudentsList> ascending = details.stream().sorted((a, b) -> Integer.compare(a.total, b.total)).collect(Collectors.toList());
                String[] columns = {"Name", "ID", "Gender", "Place", "Total"};
                DefaultTableModel model = new DefaultTableModel(columns, 0);
                JTable table = new JTable(model);
                for(StudentsList student : ascending){
                    model.addRow(new Object[]{student.name, student.id, student.gender, student.place, student.total});
                }
                JScrollPane scrollPane = new JScrollPane(table);
                scrollPane.setBounds(50, 160, 400, 200);
                frame.add(scrollPane);
            }else if(cb.getSelectedIndex()==1){
                List<StudentsList> descending = details.stream().sorted((b, a) -> Integer.compare(a.total, b.total)).collect(Collectors.toList());
                String[] columns = {"Name", "ID", "Gender", "Place", "Total"};
                DefaultTableModel model = new DefaultTableModel(columns, 0);
                JTable table = new JTable(model);
                for(StudentsList student : descending){
                    model.addRow(new Object[]{student.name, student.id, student.gender, student.place, student.total});
                }
                JScrollPane scrollPane = new JScrollPane(table);
                scrollPane.setBounds(50, 160, 400, 200);
                frame.add(scrollPane);
            }
        });
        
        JRadioButton rbMale = new JRadioButton("male");
        rbMale.setBounds(100, 40, 100, 20);
        frame.add(rbMale);
        
        JRadioButton rbFemale = new JRadioButton("female");
        rbFemale.setBounds(100, 60, 100, 20);
        frame.add(rbFemale);
        
        ButtonGroup bg = new ButtonGroup();
        bg.add(rbMale);
        bg.add(rbFemale);
        
        Map<Boolean, List<StudentsList>> mp = details.stream().collect(Collectors.partitioningBy(x -> x.gender.equals("male")));
        rbMale.addActionListener((ActionEvent e)->{
            if(rbMale.isSelected()){
                List<StudentsList> male = mp.get(true);
                String[] columns = {"Name", "ID", "Gender", "Place", "Total"};
                DefaultTableModel model = new DefaultTableModel(columns, 0);
                JTable table = new JTable(model);
                for(StudentsList student : male){
                    model.addRow(new Object[]{student.name, student.id, student.gender, student.place, student.total});
                }
                JScrollPane scrollPane = new JScrollPane(table);
                scrollPane.setBounds(50, 160, 400, 200);
                frame.add(scrollPane);
                
            }
            
        });
            
        rbFemale.addActionListener((ActionEvent ex)->{
            if(rbFemale.isSelected()){
                List<StudentsList> female = mp.get(false);
                String[] columns = {"Name", "ID", "Gender", "Place", "Total"};
                DefaultTableModel model = new DefaultTableModel(columns, 0);
                JTable table = new JTable(model);
                for(StudentsList student : female){
                    model.addRow(new Object[]{student.name, student.id, student.gender, student.place, student.total});
                }
                JScrollPane scrollPane = new JScrollPane(table);
                scrollPane.setBounds(50, 160, 400, 200);
                frame.add(scrollPane);
            }
        });
        
       
        JCheckBox pkl = new JCheckBox("By Palakol"); 
        JCheckBox hyd = new JCheckBox("By Hyderabad"); 
        JCheckBox kdr = new JCheckBox("By Koderu");
        JCheckBox plm = new JCheckBox("By Palem");
        pkl.setBounds(100, 80, 100, 20);
        frame.add(pkl);
        hyd.setBounds(100, 100, 120, 20);
        frame.add(hyd);
        kdr.setBounds(100, 120, 100, 20);
        frame.add(kdr);
        plm.setBounds(100, 140, 100, 20);
        frame.add(plm);
        
        Map<String, List<StudentsList>> places = details.stream().collect(Collectors.groupingBy(x -> x.place));
        pkl.addActionListener((ActionEvent pk)->{
            
            String place = "palakol";
            List<StudentsList> palakol = places.get(place);
            String[] columns = {"Name", "ID", "Gender", "Place", "Total"};
                DefaultTableModel model = new DefaultTableModel(columns, 0);
                JTable table = new JTable(model);
                for(StudentsList student : palakol){
                    model.addRow(new Object[]{student.name, student.id, student.gender, student.place, student.total});
                }
                JScrollPane scrollPane = new JScrollPane(table);
                scrollPane.setBounds(50, 160, 400, 200);
                frame.add(scrollPane);
            
        });
        
        
        
        frame.setSize(500,500);
        frame.setLayout(null);
        frame.setDefaultCloseOperation(frame.EXIT_ON_CLOSE);
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }
}
