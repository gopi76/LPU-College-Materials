package combinedpractice;

//Jmenu, textarea, file creation, jdbc

import java.awt.*;
import java.awt.event.ActionEvent;
import javax.swing.*;
import java.sql.*;
import java.nio.file.*;

public class Practice2 {
    public static void main(String[] args){
        JFrame frame = new JFrame("Combined");
        JMenuBar mb = new JMenuBar();
        JMenu file = new JMenu("File");
        mb.add(file);
        JMenu edit = new JMenu("Edit");
        mb.add(edit);
        JMenu view = new JMenu("View");
        mb.add(view);
        
        JMenuItem saveFile = new JMenuItem("Save to File");
        file.add(saveFile);
        JMenuItem saveJDBC = new JMenuItem("Save to DataBase");
        file.add(saveJDBC);
        frame.setJMenuBar(mb);
        
        JTextArea textArea = new JTextArea();
        textArea.setBounds(0, 0, 400, 400);
        textArea.setBackground(Color.LIGHT_GRAY);
        frame.add(textArea);
        
        saveFile.addActionListener((ActionEvent e)->{
            String data = textArea.getText();
            
            try{
                Path p = Paths.get("DataSet/Practice2.txt");
                if(Files.exists(p)){
                    JOptionPane.showMessageDialog(frame, "File Already Created");
                } else {
                    Path donePath = Files.createFile(p);
                    Files.write(donePath, data.getBytes());
                    JOptionPane.showMessageDialog(frame, "File Created Successfully");
                }
                
            }catch(Exception Fe){
                System.out.println(Fe);
            }
        });
        
        saveJDBC.addActionListener((ActionEvent e)->{
            String data = textArea.getText();
            try{
                Class.forName("com.mysql.cj.jdbc.Driver");
                Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/students", "root", "2002");
                PreparedStatement ps = connection.prepareStatement("INSERT INTO TEXTDATA VALUES(?)");
                ps.setString(1, data);
                int i = ps.executeUpdate();
                if(i>0){
                    JOptionPane.showMessageDialog(frame, "Data saved to DataBase");
                } else {
                    JOptionPane.showMessageDialog(frame, "Data failed to save to DataBase");
                }
                connection.close();
             }
             catch(Exception sql){
                 System.out.println(sql);
             }
        });
        
        
        frame.setSize(400, 400);
        frame.setLayout(null);
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
        frame.setDefaultCloseOperation(frame.EXIT_ON_CLOSE);
        
    }
}
