package parallelStreams;

import java.util.Arrays;
import java.util.List;

class Students{
    String name;
    int score;
    
    public Students(String name, int score){
        this.name = name;
        this.score = score;
    }
    
    public String getName(){
        return name;
    }
    
    public int getScore(){
        return score;
    }
}

public class ParallelStreamsDemoPractice {
    public static void main(String[] args){
        List<Students> studentLists = Arrays.asList(
                new Students("Sunkara", 86),
                new Students("Lithin", 89),
                new Students("Naga", 87),
                new Students("Datta", 88),
                new Students("Sravan", 95),
                new Students("Datthu", 90)
        );
        
        studentLists.stream()
                .filter(x -> x.score>=85)
                .limit(3)
                .forEach(x -> System.out.println(x.name+" "+x.score));
        System.out.println();
                
    }
}
