package javanio;

import java.nio.file.*;
import java.util.*;

public class WriteToFile {
    public static void main(String[] args){
        try{
//            Path p1 = Paths.get("DataSet/newtext.txt");
//            Path donePath1 = Files.createFile(p1);
//            
//            String content = "Nenu emantanante...";
//            Files.write(donePath1, content.getBytes());
//            System.out.println("Data written as byte array");
            
            Path p2 = Paths.get("DataSet/newtext2.txt");
            Path donePath2 = Files.createFile(p2);
            
            Path p3 = Paths.get("DataSet/poem.txt");
            List<String> data = Files.readAllLines(p3);
            
            Files.write(donePath2, data);
            System.out.println("Data written in File using List of String");
        }
        catch(Exception e){
            System.out.println(e);
        }
    }
}
