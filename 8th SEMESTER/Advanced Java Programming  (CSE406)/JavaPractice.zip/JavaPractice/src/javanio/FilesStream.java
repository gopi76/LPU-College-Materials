package javanio;

import java.nio.file.*;
import java.util.stream.*;

public class FilesStream {
    public static void main(String[] args){
        try{
            Stream<Path> files = Files.list(Paths.get("."));
            files.forEach(System.out::println);
        }
        catch(Exception e){
            System.out.println(e);
        }
    }
}
