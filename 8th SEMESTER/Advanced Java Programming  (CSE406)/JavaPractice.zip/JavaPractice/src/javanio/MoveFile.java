package javanio;

import java.nio.file.*;

public class MoveFile {
    public static void main(String[] args){
        try{
            Path source = Paths.get("sourceFile.txt");
            Path destination = Paths.get("DataSet/sourceFile.txt");
            
            Files.move(source, destination);
        }
        catch(Exception e){
            System.out.println(e);
        }
    }
    
}
