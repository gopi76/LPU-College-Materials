package javanio;

import java.nio.file.Path;
import java.nio.file.Paths;

public class JavaNIOPractice {
    public static void main(String[] args){
        try{
            Path path = Paths.get("C:\\Users\\srava\\OneDrive\\Documents\\.ppts\\CSE 406");
            System.out.println(path.getFileName());
            System.out.println(path.getName(0));
            System.out.println(path.getName(1));
            System.out.println(path.getName(2));
            System.out.println(path.getName(3));
            System.out.println(path.getName(4));
            System.out.println(path.getNameCount());
            System.out.println(path.isAbsolute());
            System.out.println(path.getRoot());
            System.out.println(path.getParent());
            System.out.println(path.subpath(0, 2));
            System.out.println(path);
            path.resolve("sample");
            System.out.println(path);
            
        }
        catch(Exception e){
            System.out.println(e);
        }
    }
    
}
