package javanio;

import java.nio.file.*;
import java.nio.*;

public class CreateFile {
    public static void main(String[] args){
        try{
            Path p = Paths.get("DataSet/poem.txt");
            if(Files.exists(p)){
                System.out.println("File already exists");
            }
            else{
                Path donePath = Files.createFile(p);
                System.out.println("File successfully created at "+donePath.toString());
            }
        }
        catch(Exception e){
            System.out.println(e);
        }
    }
}
