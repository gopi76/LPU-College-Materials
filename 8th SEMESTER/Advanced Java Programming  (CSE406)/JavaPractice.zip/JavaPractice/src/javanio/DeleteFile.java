package javanio;

import java.nio.file.*;

public class DeleteFile {
    public static void main(String[] args){
        try{
            Path p = Paths.get("DataSet/destinationFile.txt");
            Files.delete(p);
            System.out.println("File Successfully deleted");
        }
        catch(Exception e){
            System.out.println(e);
        }
    }
    
}
