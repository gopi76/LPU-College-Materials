package javanio;

import java.nio.file.*;

public class AppendToFile {
    public static void main(String[] args){
        try{
            Path p = Paths.get("DataSet/poem.txt");
            
            String str = "next line lo vasthadhi";
            
            Files.write(p, str.getBytes(), StandardOpenOption.APPEND);
        }
        catch(Exception e){
            System.out.println(e);
        }
    }
    
}
