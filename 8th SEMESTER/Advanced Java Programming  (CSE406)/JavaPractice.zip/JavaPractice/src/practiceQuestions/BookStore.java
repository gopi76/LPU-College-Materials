package practiceQuestions;

//Write a program in Java to create a GUI application for a bookstore. 
//The application should allow users to search for books by title, author, or genre. 
//Display the search results in a table format, including details like title, author, 
//price, and availability.

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.util.List;
import java.util.Arrays;
import javax.swing.table.DefaultTableModel;

public class BookStore {
    String title;
    String author;
    String genre;
    Double price;
    Boolean availability;
    
    public BookStore(String title, String author, String genre, Double price, Boolean availability){
        this.title = title;
        this.author = author;
        this.genre = genre;
        this.price = price;
        this.availability = availability;
    }
    
    public static void main(String[] args){
        JFrame frame = new JFrame("BookStore");
        
        JLabel searchLabel = new JLabel("Search");
        searchLabel.setBounds(100, 10, 50, 50);
        frame.add(searchLabel);
        
        JTextField searchField = new JTextField(10);
        searchField.setBounds(150, 30, 80, 20);
        frame.add(searchField);
        
        JButton submit = new JButton("submit");
        submit.setBounds(150, 50, 80, 20);
        frame.add(submit);
        
        List<BookStore> bookstore = Arrays.asList(
            new BookStore("To Kill a Mockingbird", "Harper Lee", "Fiction", 10.99, true),
            new BookStore("1984", "George Orwell", "Dystopian Fiction", 9.99, true),
            new BookStore("The Great Gatsby", "F. Scott Fitzgerald", "Classic Literature", 8.99, false)
        );
        
        String[] columns = {"Title", "Author", "Price", "Availability"};
        
        DefaultTableModel model = new DefaultTableModel(columns, 0);
        JTable table = new JTable(model);
        
        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBounds(50, 100, 300, 200);
        frame.add(scrollPane);
        
        
        submit.addActionListener((ActionEvent e) -> {
            String text = searchField.getText();
            model.setRowCount(0);
            
            for(BookStore book : bookstore){
                if(book.title.toLowerCase().contains(text.toLowerCase())){
                    model.addRow(new Object[]{book.title, book.author, book.price, book.availability ? "In Stock" : "Out of Stock"});
                }
            }
        });
        
        frame.setSize(400, 400);
        frame.setLayout(null);
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
        frame.setDefaultCloseOperation(frame.EXIT_ON_CLOSE);
    }
    
}
