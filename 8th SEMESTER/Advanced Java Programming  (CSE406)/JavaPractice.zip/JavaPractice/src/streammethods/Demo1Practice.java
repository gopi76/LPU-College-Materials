package streammethods;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class Demo1Practice {
    public static void main(String[] args){
        List<String> vehicleList = Arrays.asList("car", "bike", "car", "plane", "plane", "rocket");
        System.out.println(vehicleList);
        
        List<String> distinctVehicleList = vehicleList.stream().distinct().collect(Collectors.toList());
        System.out.println(distinctVehicleList);
        
        long count = vehicleList.stream().count();
        System.out.println(count);
        
        long count2 = distinctVehicleList.stream().count();
        System.out.println(count2);
        
        List<String> limited = vehicleList.stream().limit(3).collect(Collectors.toList());
        System.out.println(limited);
    }
}
