package com.example.sqldatabase

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast

class MainActivity : AppCompatActivity() {
    lateinit var enter_name: EditText
    lateinit var enter_age: EditText
    lateinit var add_btn: Button
    lateinit var display_btn: Button
    lateinit var display_name: TextView

        lateinit var display_age:TextView
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        enter_name = findViewById(R.id.editTextTextPersonName)
        enter_age = findViewById(R.id.editTextNumber)
        display_name = findViewById(R.id.textView4)
        display_age = findViewById(R.id.textView5)
        add_btn = findViewById(R.id.button)
        display_btn = findViewById(R.id.button2)
        add_btn.setOnClickListener {
//            if(enter_age.text.toString() == "") {
//                enter_name.error = "enter name"
//            }
//            if(enter_age.text.toString() == "") {
//                enter_age.error = "enter age"
//            }
            val db = DBHelper(this, null)
            val name = enter_name.text.toString()
            val age = enter_age.text.toString()
            db.addName(name, age)
            Toast.makeText(this, "${name} added to database", Toast.LENGTH_SHORT).show()
            enter_name.text.clear()
            enter_age.text.clear()
        }
        display_btn.setOnClickListener {
            val db = DBHelper(this, null)
            val cursor = db.getName()
            cursor?.moveToFirst()
            while (!cursor?.isAfterLast!! == true) {
                var index = cursor.getColumnIndex("name")
                val name = cursor.getString(index)
                index = cursor.getColumnIndex("age")
                val age = cursor.getString(index)
                display_name.text = name.toString()
                display_age.text = age.toString()
                cursor.moveToNext()
            }
        }
    }
}